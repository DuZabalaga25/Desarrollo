# Python con PostgreSQL
# Importando Libreria psycopg2 para conectar Python con PostgreSQL
import psycopg2


def connectionBD():
    try:
        # Parámetros de conexión a PostgreSQL
        connection = psycopg2.connect(
            host="localhost",      # Host de la base de datos
            user="postgres",       # Usuario de la base de datos
            password="postgres",  # Contraseña del usuario
            database="unodc",    # Nombre de la base de datos
            port="5432"            # Puerto de PostgreSQL (por defecto es 5432)
        )
        
        # Verificar si la conexión fue exitosa
        if connection:
            # print("Conexión exitosa a la BD")
            return connection

    except psycopg2.Error as error:
        print(f"No se pudo conectar: {error}")


